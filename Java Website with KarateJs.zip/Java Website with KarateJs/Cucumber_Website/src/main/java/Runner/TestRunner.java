package Runner;

import org.junit.runner.RunWith;

import com.intuit.karate.junit4.Karate;

import cucumber.api.CucumberOptions;

@RunWith(Karate.class)
@CucumberOptions(
		features = "C:\\Users\\AK5051250\\Documents\\Cucumber_Website\\Cucumber_Website\\src\\main\\java\\Feature\\Login.feature"
		,glue={"stepDefinition"}
		)
public class TestRunner {

}
